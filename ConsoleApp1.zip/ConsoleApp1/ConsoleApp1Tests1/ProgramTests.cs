﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1;
namespace Tests
{
    [TestClass]
    public class ProgramTests
    {
        [TestMethod]
        public async Task MainTest()
        {
            await Program.Main();
        }
        [TestMethod]
        public async Task FetchAndStoreWeatherTest()
        {
            await Program.FetchAndStoreWeather("2988507", "Paris");
        }
    }
}