﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class FileLogger : ILogger
    {
        public void Log(string message, string outputpath="output", string filename = "")
        {
            JObject weatherData = JObject.Parse(message);
            string outputFilePath = Path.Combine(outputpath, filename);
            File.WriteAllText(outputFilePath, weatherData.ToString());
        }
    }
}
