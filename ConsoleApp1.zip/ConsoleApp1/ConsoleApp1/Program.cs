﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using ConsoleApp1;
using Newtonsoft.Json.Linq;

public class Program
{
    private static readonly string apiKey = "aa69195559bd4f88d79f9aadeb77a8f6";
    private static readonly string baseUrl = "http://api.openweathermap.org/data/2.5/weather";
    private static readonly string outputFolderPath = "output";
    private static readonly string inputFolderPath = "input/cities.txt";
    private ILogger? _logger;  
    public Program(ILogger? logger)
    {
       _logger = logger;
    }

    public Program()
    {

    }
    public static async Task Main()
    {
        ExceptionLogger expLog = ExceptionLogger.GetInstance();
        try
        {
            if (!Directory.Exists(outputFolderPath))
            {
                Directory.CreateDirectory(outputFolderPath);
            }
            string[] cityLines = File.ReadAllLines(Path.Combine(inputFolderPath));
            foreach (string line in cityLines)
            {
                if (!string.IsNullOrEmpty(line) && line.Contains("="))
                {
                    var parts = line.Split('=');
                    if (parts != null && parts.Length == 2)
                    {
                        string cityId = parts[0].Trim();
                        string cityName = parts[1].Trim();
                        if (!string.IsNullOrEmpty(cityId))
                        {
                            await FetchAndStoreWeather(cityId, cityName);
                        }
                    }
                }
            }
            Console.WriteLine("File Upload Completed....");
        }
        catch(Exception ex)
        {
            expLog?.Log(ex.ToString());
            Console.WriteLine("File Upload Failed....");
        }
    }

    public static async Task FetchAndStoreWeather(string cityId, string cityName)
    {
        FileLogger fn = new FileLogger();
        Program pg = new Program(fn);
        ExceptionLogger expLog = ExceptionLogger.GetInstance();
        try
        {            
            using (HttpClient client = new HttpClient())
            {
                string requestUrl = $"{baseUrl}?id={cityId}&appid={apiKey}&units=metric";
                HttpResponseMessage response = await client.GetAsync(requestUrl);
                if (response != null && response.IsSuccessStatusCode)
                {
                    string responseData = await response.Content.ReadAsStringAsync();
                    string filename = $"{cityName}_{DateTime.UtcNow:yyyyMMdd}.json";
                    pg._logger?.Log(responseData, outputFolderPath, filename);               
                    
                }
                else
                {
                    expLog.Log($"Failed to retrieve data for {cityName}: {response?.StatusCode}");
                }
            }            
        }
        catch(Exception ex)
        {
            expLog.Log($"Exception For City {cityName} - " + ex.ToString());

        }
        
    }
}