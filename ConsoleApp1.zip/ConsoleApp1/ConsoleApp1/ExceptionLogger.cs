﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{

    public sealed class ExceptionLogger : ILogger
    {
        private static ExceptionLogger? instance = null;
        private ExceptionLogger()
        {

        }
        private static readonly object padlock = new object();
        public static ExceptionLogger GetInstance()
        {
            lock (padlock)
            {
                if (instance == null)
                {
                    instance = new ExceptionLogger();
                }
                return instance;
            }
        }
        public void Log(string message, string outputpath = "", string filename = "")
        {
            string outputFolderPath = "ExceptionLog";
            if (!Directory.Exists(outputFolderPath))
            {
                Directory.CreateDirectory(outputFolderPath);
            }
            string outputFilePath = Path.Combine(outputFolderPath, "explog.txt");
            File.AppendAllText(outputFilePath, Environment.NewLine + DateTime.Now.ToString() + " - " + message.ToString());
        }
    }
}
