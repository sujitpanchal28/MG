using Microsoft.AspNetCore.Mvc;
using OpenWeatherService.Models;
using OpenWeatherService.Services;

namespace OpenWeatherService.API.Controllers;

[ApiController]
[Route("api/")]
public class WeatherForecastController : ControllerBase
{
    private readonly IWeatherService _weatherService;

    public WeatherForecastController(IWeatherService weatherService)
    {
        _weatherService = weatherService;
    }

    [HttpGet("forecast")]
    public async Task<IActionResult> GetWeatherForecasts(string cityId= "2643741", string cityName= "City of London")
    {
        var response = await _weatherService.FetchWeatherForecast(cityId, cityName);
        return Ok(response);
    }
}
