﻿using System.Net.Http.Json;
using Newtonsoft.Json;
using OpenWeatherService.Models;

namespace OpenWeatherService.Services;

public class WeatherService : IWeatherService
{
    private static readonly HttpClient _httpClient = new HttpClient { };
    private static readonly string apiKey = "aa69195559bd4f88d79f9aadeb77a8f6";
    private static readonly string baseUrl = "http://api.openweathermap.org/data/2.5/weather";
    private static readonly string outputFolderPath = "output";
    private static readonly string inputFolderPath = "input/cities.txt";


    //public IEnumerable<SearchLocation> FetchLocation(string query, string lang = "en")
    //{
    //    ValidateWeatherApiSettings();

    //    string apiUrl = $"{WEATHER_API_URL}/search.json?key={WEATHER_API_KEY}&q={query}&lang={lang}";

    //    HttpResponseMessage response = _httpClient.GetAsync(apiUrl).Result;

    //    if (response.IsSuccessStatusCode)
    //    {
    //        var result = response.Content.ReadFromJsonAsync<IEnumerable<SearchLocation>>().Result;
    //        return result!;
    //    }

    //    throw new HttpRequestException($"Weather API request failed with status code {response.StatusCode}");
    //}

    //public Weather FetchWeatherForecast(string query, int days = 3, string lang = "en")
    //{
    //    ValidateWeatherApiSettings();

    //    string apiUrl = $"{WEATHER_API_URL}/forecast.json?key={WEATHER_API_KEY}&q={query}&days={days}&lang={lang}";

    //    HttpResponseMessage response = _httpClient.GetAsync(apiUrl).Result;

    //    if (response.IsSuccessStatusCode)
    //    {
    //        var result = response.Content.ReadFromJsonAsync<Weather>().Result;
    //        return result!;
    //    }

    //    throw new HttpRequestException($"Weather API request failed with status code {response.StatusCode}");
    //}

    public async Task<WeatherResponse> FetchWeatherForecast(string cityId, string cityName)
    {
        WeatherResponse? weatherData = null;
        try
        {
            using (HttpClient client = new HttpClient())
            {
                
                string requestUrl = $"{baseUrl}?id={cityId}&appid={apiKey}&units=metric";
                HttpResponseMessage response = _httpClient.GetAsync(requestUrl).Result;
                if (response != null && response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    weatherData = JsonConvert.DeserializeObject<WeatherResponse>(content);
                }
                else
                {
                    throw new Exception($"Failed to retrieve data for {cityName}: {response?.StatusCode}");
                }
            }
            return weatherData;
        }
        catch (Exception ex)
        {
            throw new Exception($"Exception For City {cityName} - " + ex.ToString());

        }
    }
}
