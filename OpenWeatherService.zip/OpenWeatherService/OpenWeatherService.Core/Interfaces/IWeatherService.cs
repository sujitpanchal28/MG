﻿using OpenWeatherService.Models;

namespace OpenWeatherService.Services;

public interface IWeatherService
{
    public Task<WeatherResponse> FetchWeatherForecast(string cityId, string cityName);
}
