﻿using Newtonsoft.Json;
using System.Drawing;

namespace OpenWeatherService.Models
{
    public class WeatherResponse
    {
        [JsonProperty("weather")]
        public List<Weather>? weather { get; set; }
        
        [JsonProperty("id")]
        public int? ID { get; set; }

        [JsonProperty("name")]
        public string? Name { get; set; }
        [JsonProperty("timezone")]
        public string? TimeZone { get; set; }
    }

    public class Weather
    {
        
        public Weather(int ID, string Main, string Description, string Icon)
        {
            this.ID = ID;
            this.Main = Main;
            this.Description = Description;
            this.Icon = Icon;
        }

        [JsonProperty("id")]
        public int? ID { get; set; }

        [JsonProperty("main")]
        public string? Main { get; set; }

        [JsonProperty("description")]
        public string? Description { get; set; }

        [JsonProperty("icon")]
        public string? Icon { get; set; }

    }

}