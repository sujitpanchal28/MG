using Moq;
using OpenWeatherService.Services;
using OpenWeatherService.API.Controllers;
using Microsoft.AspNetCore.Mvc;
using OpenWeatherService.Models;
using System.Net;

namespace OpenWeatherService.UnitTest
{
    [TestFixture]
    public class WeatherForecastControllerTest
    {
        private WeatherForecastController _weatherForecastController;
        private Mock<IWeatherService> _weatherServiceMock;

        [SetUp]
        public void Setup()
        {
            _weatherServiceMock = new Mock<IWeatherService>();
            _weatherForecastController = new WeatherForecastController(_weatherServiceMock.Object);
        }

        [Test]
        public async Task Get_FetchWeatherForecast()
        {
            List<Weather> lstwether = new List<Weather>();
            lstwether.Add(new Weather(802, "Clouds", "scattered clouds", "03d"));
            WeatherResponse response = new WeatherResponse{ID= 2950159, Name="Berlin",TimeZone= "7200",weather = lstwether};

            _weatherServiceMock.Setup(service => service.FetchWeatherForecast(It.IsAny<string>(), It.IsAny<string>()))
                      .ReturnsAsync(response);

            // Act
            var result = await _weatherForecastController.GetWeatherForecasts("2950159", "Berlin");

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okObjectResult = (OkObjectResult)result;
            Assert.NotNull(okObjectResult);

            var model = (WeatherResponse?)okObjectResult.Value;
            Assert.NotNull(model);

        }
    }
}